<?php

// Conexion con la base de datos
class Conexion extends PDO {

    private $db_host = 'mysql';
    private $db_name = 'UOC_transfers';
    private $db_user = 'user';
    private $db_pass = 'password';

    public function __construct() {
        try {
            parent::__construct("mysql:host={$this->db_host};dbname={$this->db_name};charset=utf8", $this->db_user, $this->db_pass);
        } catch (PDOException $e) {
            echo 'Error en la conexión a la base de datos: ' . $e->getMessage();
            exit;
        }
    }

}

?>