<?php
//Llamamos a la vista de login
require('./views/login_view.php');
?>