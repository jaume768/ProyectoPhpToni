<?php
//Se tendrían que cargar todas las reservas para mostrarlas pero por ahora solo navegamos a su panel
require('../views/admin_view.php');
?>