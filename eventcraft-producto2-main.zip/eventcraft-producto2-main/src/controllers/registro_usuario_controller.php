<?php

//Información enviada por el formulario
$nombre = $_POST['nombre'];
$apellido1 = $_POST['apellido1'];
$apellido2 = $_POST['apellido2'];
$direccion = $_POST['direccion'];
$codigoPostal = $_POST['codigoPostal'];
$ciudad = $_POST['ciudad'];
$pais = $_POST['pais'];
$email = $_POST['email'];
$pass = $_POST['password'];

//Llamamos al modelo
require_once(dirname(__FILE__).'/../models/usuario.php');
$usuario = new Usuario();

try{
    $success = $usuario->registro_usuario($nombre, $apellido1, $apellido2, $direccion,
                                          $codigoPostal, $ciudad, $pais, $email, $pass);
} catch (Exception $e) {
    header('Location:../views/login_view.php?msg='.$e->getMessage());
    exit();
}

if ($success == true){
    header('Location:../views/login_view.php?msg=Usuario creado correctamente');
    exit();
} else {
    header('Location:../views/login_view.php?msg=Error al crear el usuario');
    exit();
}
