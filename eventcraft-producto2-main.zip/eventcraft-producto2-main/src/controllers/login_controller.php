<?php

//Información enviada por el formulario
$email = $_POST['email'];
$pass = $_POST['password'];

/*Se pasan las comprobaciones al propio formulario
//Primero comprobamos que no esten vacios
if (empty($email)){
    header('Location:../views/login_view.php?msg=Introduzca el correo electronico');
    exit();
}

if (empty($pass)){
    header('Location:../views/login_view.php?email='.$email.'&msg=Introduzca la contraseña');
    exit();
}*/

//Si es el administrador navegamos al controlador del panel de administrador
if ($email == 'admin' and $pass == '1234') {
    require('admin_controller.php');
    exit();
}

//Llamamos al modelo e instanciamos el objeto
require_once(dirname(__FILE__).'/../models/usuario.php');
$usuarios = new Usuario();

//Comprobamos si existe el usuario
$usuario = $usuarios->login_usuario($email, $pass);

//Si no existe como usuario miramos si es conductor
if ( empty($usuario)) {
    require_once(dirname(__FILE__).'/../models/conductor.php');
    $conductores = new Conductor();

    $conductor = $conductores->login_conductor($email, $pass);

    //Si no existe tampoco como conductor mandamos un mensaje de que el usuario no existe
    //if ($conductor == false) {
    if ( empty($conductor) ) {
        header('Location:../views/login_view.php?email='.$email.'&msg=Error en el usuario o contraseña');        
        exit();
    }else{
        require('conductor_controller.php');
        exit();
    }

}else{
    //Si existe el usuario navegamos al controlador del panel de usuario
    require('usuario_controller.php');
    exit();
}


?>
