<?php
//Se tendrían que cargar todas las rutas asignadas para mostrarlas pero por ahora solo navegamos a su panel
require('../views/conductor_view.php');
?>