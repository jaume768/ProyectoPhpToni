<!DOCTYPE html>
<html>
    <head>
        <title>Registro Viajero</title>   
        <style>
        .container {
            position: absolute;
            top: 40%;
            left: 50%;
            transform: translate(-50%, -50%);
            border: 2px solid #000000;
            border-radius: 5px;
            background-color: #f2f2f2;
            padding: 40px;
            text-align: right;
        }
        h2 {
            text-align: center;
        }
        .msg {
            text-align: center;
        }
        input, select, textarea {
            width: 50%;
        }
        </style>  
    </head>
    <body>
        <div class="container">
            <h2>REGISTRO</h2>
            <form action='../controllers/registro_usuario_controller.php' method="post">            
                <?php if (isset($_GET['error'])) { ?>
                    <p class="error"><?php echo $_GET['error']; ?></p>
                <?php } ?><br>
                <label for="nombre">Nombre: </label>
                <input type="text" name="nombre" placeholder="Nombre" maxlength="100" required><br><br>
                <label for="apellido1">Primer Apellido: </label>
                <input type="text" name="apellido1" placeholder="Primer Apellido" maxlength="100" required><br><br>
                <label for="apellido2">Segundo Apellido: </label>
                <input type="text" name="apellido2" placeholder="Segundo Apellido" maxlength="100" required><br><br>
                <label for="direccion">Direccion: </label>
                <input type="text" name="direccion" placeholder="Direccion" maxlength="100" required><br><br>
                <label for="codigoPostal">Codigo Postal: </label>
                <input type="text" name="codigoPostal" placeholder="Codigo Postal" minlength="5" maxlength="5" required><br><br>
                <label for="ciudad">Ciudad: </label>
                <input type="text" name="ciudad" placeholder="Ciudad" maxlength="100" required ><br><br>
                <label for="pais">Pais: </label>
                <input type="text" name="pais" placeholder="Pais" maxlength="100" required ><br><br>
                <label for="email">Email: </label>
                <input type="email" name="email" placeholder="Correo Electronico" maxlength="100" required><br><br>
                <label for="password">Password: </label>
                <input type="password" name="password" placeholder="Password" maxlength="100" required><br><br> 
                <button type="submit" value="Login">Aceptar</button><br><br>
            </form>
        </div>
    </body>
</html>