<?php
echo ('Panel del administrador');
?>