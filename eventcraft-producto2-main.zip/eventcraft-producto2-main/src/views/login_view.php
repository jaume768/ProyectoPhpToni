<!DOCTYPE html>
<html>
    <head>
        <title>Login</title>
        <style>
        .container {
            position: absolute;
            top: 30%;
            left: 50%;
            transform: translate(-50%, -50%);
            border: 2px solid #000000;
            border-radius: 5px;
            background-color: #f2f2f2;
            padding: 20px;
            text-align: right;
        }
        h2 {
            text-align: center;
        }
        .msg {
            text-align: center;
        }
        </style> 
    </head>
    <body>
        <div class="container">
            <h2>LOGIN</h2>
            <form action='../controllers/login_controller.php' method="post">            
                <?php if (isset($_GET['msg'])) { ?>
                    <p class="msg"><?php echo $_GET['msg']; ?></p>
                <?php } ?><br>
                <label for="email">Usuario o Email: </label>
                <input type="text" name="email" placeholder="Usuario o Correo Electronico" maxlength="100" required value=<?php if (isset($_GET['email'])) echo $_GET['email']; ?>><br><br>
                <label for="password">Password: </label>
                <input type="password" name="password" placeholder="Password" maxlength="100" required><br><br>
                <button type="submit" value="Login">Login</button><br><br>
                <a href="../controllers/registro_controller.php?tipo=usuario">Registrarse</a>
            </form>
        </div>
    </body>
</html>