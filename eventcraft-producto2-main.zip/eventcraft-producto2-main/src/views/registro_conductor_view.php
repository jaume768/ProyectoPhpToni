<?php
echo ('Vista de registro de conductor');
?>